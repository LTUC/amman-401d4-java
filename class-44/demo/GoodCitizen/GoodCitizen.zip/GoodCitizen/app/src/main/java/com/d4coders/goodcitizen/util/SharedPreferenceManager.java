package com.d4coders.goodcitizen.util;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferenceManager {

    private Context context;

    SharedPreferences sharedPreferences;

    public SharedPreferenceManager(Context context) {
        this.context = context;
    }


}
